#include "AI.h"
#include <string>
#include <iostream>
#include <algorithm>
#include <map>

using std::map;
using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::max;

map<string,int> type = {{"DIAMD",1},{"GOLD",2},{"SILVR",3},{"LEATH",4},{"SPICE",5},{"CLOTH",6},{"CAMEL",7}};

AI::AI(Deck &deck, string AIname):Player(deck, AIname){}

void AI::setAction(){}

void AI::setaction(Market& myMarket, Deck& myDeck, All_Bonus& myBonus, All_Tokens& myTokens){
  vector<vector<string>> types = {{},{}};
  unsigned int i;
  /* if((take+sell+trade+take_camel)!=1){
    cout << "WARNING: Multiple desicions" << endl;
  }
  */

  if(take == 1){
    iTrans(take_T,types.at(0));
    cout<<"AI takes 1 ";
    cout<<types.at(0).at(0)<<endl;
    Take(take_L.at(0),myMarket,myDeck);
 
  }

  else if(sell == 1){
    //    cout<<"sell"<<endl;
    iTrans(sell_T,types.at(0));
    cout<<"AI sells ";
    cout<<sell_T.size();
    cout<< types.at(0).at(0)<<endl;
    Sell(sell_L,myTokens,myBonus);
  }

  else if(trade == 1){
    //cout<<"trade"<<endl;
    iTrans(trade_T.at(0),types.at(0));
    iTrans(trade_T.at(1),types.at(1));
    cout<<"AI trades ";
    for (i = 0;i < types.at(0).size();i++){
      cout << types.at(0).at(i);
    }
    cout<<" with ";
    for(i = 0;i < types.at(1).size();i++){
      cout <<types.at(1).size() <<endl;
    }
    Trade(trade_L.at(0),trade_L.at(1),myMarket);
  }

  else if(take_camel == 1){
    cout <<"AI takes";
    cout << Sdata.at(1).at(6);
    cout <<"camels"<<endl;
    TakeCamel(myMarket, myDeck);
  }
}



void AI::EVA(vector<int> hand, vector<int> market){

  unsigned int i;
  int cNum = getHsize2();
  vector<int> Treas_loc;
  vector<int> Treas_type;
  vector<int> Goods_type;
  vector<int> Goods_loc;

   //sell immidiately if there are five cards of the same type in hand
   if( cNum == 0 && (Sdata.at(0).at(6) == 0)){// if no cards in hand and herds
     takesth(market);
   }

   else if(alone() && (Sdata.at(0).at(6) == 0)){// if there are only single treasure cards in the hand while no camel in the herds, take a card
     takesth(market);
   }

   else if(findmost(hand) == 5){
     GoodsType(sell_T,5,1,1);
     GoodsType(sell_T,5,2,1);
     getLoc(sell_T.at(0),hand,sell_L);
     sell = 1;
   }

   // if there are four camels in the market, be the last one to take
   else if(Sdata.at(1).at(6) == 4){
     sellsth(hand);
     if(sell==0)
       takesth(market);
   }

   else if(TreaSum() == 1){
     GoodsType(Treas_type,1,1,2);// find the only one treasures in the market 
   // if there is only one treasure card in the market, and the handsize is less than 7, and if there are more than 1 tokens of that tokens, also the cards in my hand is less than 5 of that type of treasure, than take it.
     if(cNum < 7){
       if(Sdata.at(3).at(Treas_type.at(0)-1)>=1 && Sdata.at(0).at(Treas_type.at(0)-1) < 5){
	 take = 1;
	 getLoc(Treas_type.at(0),market,take_L);
	 take_T = Treas_type;
       }
     }
     else if (cNum == 7){
       sellsth(hand);
     }
   }

   else if(TreaSum() >=2){
     if((7-getHsize2())>TreaSum()&&Sdata.at(0).at(6) >= TreaSum()){
       trade = 1;
       trade_T.push_back({});
       trade_T.push_back({});
       trade_L.push_back({});
       trade_L.push_back({});
       trade_T.at(0).push_back(7);

       for(i = 0; i < 3; i++){
	 if(getLoc(i+1,market,Treas_loc)){
	   trade_T.at(1).push_back(i+1);
	 }
	 trade_L.at(1) = Treas_loc;
       }
     }
   }
   else{
       takesth(market);
   }
}


void AI::TransCard(vector<string> types,vector<int>& NumedType){

  unsigned int i;
  map<string,int>::iterator it = type.begin();

  for(i = 0; i <types.size();i++){ 
    for(it = type.begin();it != type.end(); it++){
      if(it->first == types.at(i)){
	NumedType.push_back(it->second);
	//	cout <<it ->second <<endl;
      }
    }
  }
}

void AI::iTrans(vector<int> digitalT, vector<string>& types){
  unsigned int i;
  map<string,int>::iterator it = type.begin();
  for(i = 0;i < digitalT.size(); ++i){
    for(it = type.begin(); it != type.end(); it++){
      if(it->second == digitalT.at(i)){
	types.push_back(it->first);
	//	cout<< it->first <<endl;
      }
    }
  }
}

void AI::BuildToken(All_Tokens mytoken, All_Bonus mybonus, vector<vector<int>>& AllTokenNum){

  vector<int> TokenNum;
  vector<int> BonusNum;
  int i,j;

  for( i = 1; i <= 7;i++){
    TokenNum.push_back(mytoken.getSize(i));
  }

  for( j = 3; j <= 5; j++){
    BonusNum.push_back(mybonus.getSize(j));
  }

  AllTokenNum.push_back(TokenNum);
  AllTokenNum.push_back(BonusNum);
}

int AI::findsame(int type,vector<int> myvec){
  int counter = 0;
  unsigned int i; 

  for(i = 0; i < myvec.size(); i++){
    if (myvec.at(i) == type)
      counter++;
  }
  return counter;
}

int AI::findmost(vector<int> hand){
  int i;
  int M = 0;

  for( i = 1; i <= 6; i++){// find the biggest frequency
    M = max(M, findsame(i,hand));
  }
  
  return M;
}

void AI::findcombi(vector<int>& myvec,vector<int> hand, vector<int> market){
  int i;
  int M = 0;

  for( i = 1; i <=6 ; i++){
    M = max( M, findsame(i,hand)+findsame(i,market));
  }

  for( i =1; i <=6 ; i++){
    if(findsame(i,hand)+findsame(i,market) == M)
      myvec.push_back(i);
  }
}

int AI::getHsize(vector<int>& hand){
  int hsize;
  hsize = (hand.size()-findsame(7,hand));
  if(hsize > 7)
    cout<<"WARNING : handsize bigger than 7 !!!" <<endl;
  return hsize;
}

void AI::setSdata(vector<int> hand, vector<int> market, vector<vector<int>> tokens){
   int i, j;
   vector<int> hdata;
   vector<int> mdata;

   for( i = 1; i<=7; i++){
     hdata.push_back(findsame(i,hand));
   }
   for(j = 1; j<=7; j++){
     mdata.push_back(findsame(j,market));
   }

   Sdata.push_back(hdata);
   Sdata.push_back(mdata);
   Sdata.push_back(tokens.at(0));
   Sdata.push_back(tokens.at(1));
}
 
vector<vector<int>> AI::getSdata(){
  return Sdata;
}

void AI::pSdata(){
  unsigned int i,j;
  for( i = 0; i < Sdata.size(); i++){
    for( j = 0; j < Sdata.at(i).size(); j++)
      cout<<Sdata.at(i).at(j);
    cout<<endl;
  }
}

int AI::getHsize2(){
  int i;
  int sum = 0;
  for( i = 0; i <=5 ;i++){
    sum = sum + Sdata.at(0).at(i);
  }
  return sum;
}

bool AI::getLoc(int type, vector<int> myvec, vector<int> &myLoc){
  unsigned int i;
  for( i = 0; i < myvec.size();i++){
    if(myvec.at(i) == type)
      myLoc.push_back(i+1);
  }
  if(myLoc.empty())
    return false;
  return true;
} 

int AI::TreaSum(){
  int sum;
  sum = Sdata.at(1).at(0)+Sdata.at(1).at(1)+Sdata.at(1).at(2);
  return sum;
}

void AI::GoodsType(vector<int>& myvec,int number, int option, int where){
  int i;
  // write try - catch here to test the input
  switch(option){
  case 1:{
      for(i = 0; i < 3; i++){
	if(Sdata.at(where-1).at(i) == number)
	  myvec.push_back(i + 1);
      }
      break;
  }
  case 2:{
      for( i = 3; i < 7; i++){
	if(Sdata.at(where-1).at(i) == number)
	  myvec.push_back(i+1);
      }
      break;
  }
  }
}

void AI::sellsth(vector<int> myvec){
  int i,j;
  for(i = 3; i < 7; i++){
    if(Sdata.at(0).at(i) != 0){
      getLoc(i+1,myvec,sell_L);
      sell_T.push_back(i+1);
      sell = 1;
    }
  }

  if(sell_L.empty()){
    for( j = 0; j < 2; j++){
      if(Sdata.at(0).at(j) >= 2){
	getLoc( i+1, myvec,sell_L);
	sell_T.push_back(i+1);
	sell = 1;
      }
    }
  }
}

void AI::takesth(vector<int> market){
   int i;
   vector<int> tempvec;

   if(Sdata.at(1).at(6) == 5) // if there are five camels in the market, one has to take it when no cards in hand
     take_camel = 1;
   else{
     for( i = 0; i < 6; i++){
       if(Sdata.at(1).at(i) != 0){
	 getLoc(i+1,market,tempvec);
	 take_L.push_back(tempvec.at(0));
	 take_T.push_back(i+1);
	 take = 1;
	 break;
       }
     }
   }
 }

 void AI::clean(){
   take = 0;
   sell = 0;
   trade = 0;
   take_camel = 0;
   take_L.clear();
   take_T.clear();
   sell_L.clear();
   sell_T.clear();
   trade_L.clear();
   trade_T.clear();
   Sdata.clear();
 }

bool AI::alone(){
   int i;
   int sum = 0;
   if(Sdata.at(0).at(0) <=1 && Sdata.at(0).at(1) <= 1 && Sdata.at(0).at(2) <= 1){
     for( i = 3; i < 6; i++){
       sum = sum + Sdata.at(0).at(i);
     }
     if(sum == 0)
       return true;
   }
     return false;
 }
 
void AI::gettake(){
  cout<<take_L.at(0)<<endl;
  cout<<take_T.at(0)<<endl;
}

void AI::QsetSdata(Market& myM,All_Bonus& myB,All_Tokens &myT){
  vector<vector<int>> Tokeninfo;
  vector<string> Handstr;
  vector<int> Handinfo;
  vector<string> Mstr;
  vector<int> Minfo;

  BuildToken(myT,myB,Tokeninfo);

  getAllH(Handstr);
  TransCard(Handstr,Handinfo);

  myM.getAllG(Mstr);
  TransCard(Mstr,Minfo);
  setSdata(Handinfo,Minfo,Tokeninfo);
}
