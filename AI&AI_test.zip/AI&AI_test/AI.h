/* AI is the subclass of Player*/

#ifndef AI_H
#define AI_H
#include "Player.h"
#include <string.h>

class AI: public Player
{
private:
    bool take;
    std::vector<int> take_L;//the location of the card AI will take
    std::vector<int> take_T;//the type of the card AI will take
    bool sell;
    std::vector<int> sell_L;//the location of cards AI will sell
    std::vector<int> sell_T;//the type of the cards AI will sell
    bool trade;
    std::vector<std::vector<int>> trade_L;//first row:the location of card you want to trade in you hand  second row: The location of the card in the market you want to trade.
    std::vector<std::vector<int>> trade_T;// the type of the card AI will trade

    bool take_camel;
    std::vector<std::vector<int>> Sdata;//a synthesized info vector
//first row represent number of type of cards in the hand
//second row represent number of each type of cards in market
//In each row, first element is the number of diamond,
//second element is the number of gold,
//third element is the number of silver and etc.


public:
    AI(Deck &deck, std::string AIname); // constructor of the AI
    ~AI(){};

    void setAction();// It defines the decision of AI
    void setaction(Market&,Deck&,All_Bonus&,All_Tokens&);
    void EVA(std::vector<int> hand, std::vector<int> market);//the function that build the strategy of AI's playing 
    void TransCard(std::vector<std::string>,std::vector<int>&); //Transform cards types to numbers so it can be processed more easily
    void BuildToken(All_Tokens , All_Bonus, std::vector<std::vector<int>> &);//collect infomation of number of token left and put them in a vector
    int findsame(int, std::vector<int>);// find the frequency of the certain type in hand your market
    int findmost(std::vector<int>);// find the type with biggest frequency,except camel,
    void findcombi(std::vector<int>&,std::vector<int>, std::vector<int>);// search for the biggest frequency of type both in market and hand, except camel
    void QsetSdata(Market&,All_Bonus&,All_Tokens&);// quickly build the Sdata
    void setSdata(std::vector<int> hand,std::vector<int> market, std::vector<std::vector<int>> tokens); // function used to set Sdata
    int getHsize(std::vector<int>&);//get the size of card in your hand( to rule out camels)
    int getHsize2();// get the number of cards in hand by Sdata
    std::vector<std::vector<int>> getSdata();//return Sdata(for test)
    void pSdata();//print sdata
    bool getLoc(int,std::vector<int>, std::vector<int> &);// get the location of a card in vector, and put the location in another vector
    int TreaSum();// return the number of treasures(gold diamond silvr) in the market
    void GoodsType(std::vector<int>& myvec, int number, int option, int where);// find the certain type of card of certain "number" in the market or hand, option --'1': only limits to treasure, '2':goods type for common goods and put them in a vector. "where"--'1' hand '2' market
    void sellsth(std::vector<int>);// when take and trade is not available, sell common goods or pair treasures. put their type  in the vector
    void takesth(std::vector<int> market);// when there are no card in the hand, take somthing from the market( of course, with evaluation of the prize of the things that are going to take
    void clean();// used to clear all the private data after an operation
    bool alone();//to see if there are only single treasure cards in the hand ( not include camel) 
    void iTrans(std::vector<int> digitalT,std::vector<std::string>&); // transfer the digital type to string type
        void gettake();
};
#endif 
