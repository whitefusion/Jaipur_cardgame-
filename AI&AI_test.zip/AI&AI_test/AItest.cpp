#include "Token.h"
#include "AllTokens.h"
#include "Card.h"
#include "Deck.h"
#include "Market.h"
#include "AllBonus.h"
#include "AI.h"
#include <string>
#include <iostream>
#include <vector>
#include <cassert>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::vector;

int main(){
    /*==============================test for AI============================*/
  Deck AIdeck;
  AIdeck.shuffle();//initialize shuffled deck

  All_Bonus AIbonus;
  AIbonus.shuffle();//initialize shuffled bonus

  All_Tokens AItokens;//initialize alltokens
  Market AImarket(AIdeck);//initialize market

  AI robot(AIdeck,"AI"); // initialize AI player

  vector<vector<int>> Tokeninfo; 
  //"Tokeninfo" contains two vectors
  // First vector stores the number of each type of Tokens
  //Second vector stores the number of each type of bonus
  vector<vector<int>> testToken = {{5,5,5,9,7,7,1},{6,6,6}};
  //The first row in BuildToken should be{5,5,5,9,7,7,1}
  //The second row in BuildToken should be{6,6,6}

  vector<int> Handinfo;
  //the integer in Handinfo represent the card types in hand
  vector<string> Handstr;
  vector<int> testH = {2,4,7,7,7}; 
  //The vector of the hand should be Leather,Silvr,cloth, camel,camel

  vector<int> Minfo;
  //the integer in Minfo represent the cards types in market
  vector<string> Mstr;
  vector<int> testM = {7,7,7,6,5};
 //The vector should be {7,7,7,6,5}, that represents "CAMEL","CAMEL" "CAMEL","CLOTH","SPICE" 

  //test BuildToken
    robot.BuildToken(AItokens,AIbonus,Tokeninfo);
   assert(Tokeninfo == testToken);

  //test Transfer Hand cards
  robot.getAllH(Handstr);
  robot.TransCard(Handstr,Handinfo);
  assert(Handinfo == testH); 
  //  cout<<"TTTT fixed"<<endl;

  //test Transfer Market cards
  AImarket.getAllG(Mstr);
  robot.TransCard(Mstr,Minfo);
  assert(Minfo == testM);

  // test getHsize
  int hnum = robot.getHsize(testH);
  cout<<hnum <<endl;//should be 3, two camels uncounted

  // test findsame
  assert(robot.findsame(2,testH)==1); 
  assert(robot.findsame(7,testH)==3);
  assert(robot.findsame(4,testH)==1);

  //test findmost
  vector<int> mosttype;//vector that contain the type of most number 
  vector<int> tMtype = {2,4};
  assert(robot.findmost(testH) == 1);

  //test findcombi
  vector<int> combine;//store the type that appeart most times in hand and market
  vector<int> testcombi = {2,4,5,6};
  robot.findcombi(combine,testH,testM);
  assert(combine == testcombi);


  //test setSdata, getSdata, pSdata
  vector<vector<int>> SdataT ={{0,1,0,1,0,0,3},
			       {0,0,0,0,1,1,3},
			       {5,5,5,9,7,7,1},
			       {6,6,6}
  };

//test QsetSdata
  robot.QsetSdata(AImarket,AIbonus,AItokens);
 
  //  robot.setSdata(testH,testM,testToken);
  vector<vector<int>> sdata = robot.getSdata();
  // robot.pSdata();
  assert(sdata == SdataT);

  
  //test getLoc
  vector<int> myLoc = {};
  robot.getLoc(2, testH, myLoc);
  assert(myLoc.at(0)==1);

 
  //test Treasum
  int Tsum;
  Tsum = robot.TreaSum();
  assert(Tsum == 0);

  //test GoodsType
  vector<int> Ttype;
  vector<int> test_type = {5,6};
  robot.GoodsType(Ttype,1,2,2); //the two same cards in hand is spice
  assert(Ttype == test_type);
  //cout<<"here"<<endl;
  //test iTrans
  vector<string> mystr;
  robot.iTrans(testH,mystr);
  
  //test takesth
  robot.takesth(testM);
  // robot.gettake();

  //test EVA
  robot.EVA(testH,testM);
  robot.gettake();
  robot.setaction(AImarket,AIdeck,AIbonus,AItokens);  

  cout<<"All tests for AI have passed."<<endl;
}


