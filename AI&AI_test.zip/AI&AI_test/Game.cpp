#ifndef _GAME_H
#define _GAME_H

#include "Game.h"
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>

using std::cout;
using std::endl;
using std::cin;
using std::vector;
using std::string;
//using std::strtok;

Game::Game(Deck &dd, Market &mm, Human &pp1, Human &pp2) : deck(dd), market(mm), p1(pp1), p2(pp2) { //construct a game for Human vs. Human
    bonus.shuffle();//initialize all bonus
    setRound(1);//initialize round to 1
    setTurn(1);//initialize turn to 1
    srand(time(NULL));
    if (rand() % 100 > 50)
        currplayer = 1;
    else 
        currplayer = 2;
}

Game::~Game(){

}

void Game::setRound(int r){
    round = r;
}

void Game::setTurn(int t){
    turn = t;
}

void Game::setCurrPlayer(int id){
    currplayer = id;
}

void Game::play_a_round(){
    int curr = getCurrPlayer();
    int next;
    if (curr == 1)
        next = 2;
    else 
        next = 1;

    while(!RoundTermination()){
        display(getPlayer(curr));
        play_a_turn(getPlayer(curr));
        int temp = curr;
        curr = next;
        next = temp;
        if(curr == 1){
            int currTurn = getTurn();
            setTurn(++currTurn);
        }
    }

    setCurrPlayer(roundWinner());
    int currRound = getRound();
    setRound(++currRound);

    //clear player's basic points, bonus points, total points
    for (int i = 0; i < 3; i++){
        p1.addPoint(i,-1*p1.getPoints(i));
        p2.addPoint(i,-1*p1.getPoints(i));
    }

}

void Game::play_a_turn(Player &p){
    // get uer's action
    int act;
    int take;
    vector<int> tradeM;
    vector<int> tradeH;
    vector<int> sellH;

    char tmp[256];
    char *token;

    

    cout << "Options(Take--1,  Trade--2,  Sell--3,  TakeCamel--4): ";
    cin >> act;

    while (!actionVerify(act,p)){
        cout << "Invalid action! Try again." << endl;
        cout << "Options(Take--1,  Trade--2,  Sell--3,  TakeCamel--4): ";
        cin >> act;
    }
    
    // verify the input and carry out action
    switch (act){
        // take
        case 1:
        {
            cout << "Choose the ID of the card want to take: ";
            cin >> take;
            while(!takeVerify(market, take)){
                cout << "Invalid choice! Try again: ";
                cin >> take;
            }
            // check the card # in deck, if zero, then terminate round
            p.Take(take, market, deck);
            break;
        }

        // trade
        case 2:
        {
            // read in user's input
            cout << "Choose the cards on MARKET want to take in: ";
            cin.getline(tmp, 256);
            cin.getline(tmp, 256);

            token = strtok(tmp, " \t\n\r\f");
            tradeM.push_back(atoi(token));
            token = strtok(NULL, " \t\n\r\f");
            while (token){
                tradeM.push_back(atoi(token));
                token = strtok(NULL, " \t\n\r\f");
            }

            cout << "Choose the cards on HANDS want to trade: ";
            cin.getline(tmp, 256);

            token = strtok(tmp, " \t\n\r\f");
            // if nothing input, will trade camels
            if (token != NULL){
                tradeH.push_back(atoi(token));
                token = strtok(NULL, " \t\n\r\f");
                while (token){
                    tradeH.push_back(atoi(token));
                    token = strtok(NULL, " \t\n\r\f");
                }        
            }

            while(!tradeVerify(tradeM, tradeH, p, market)){
                tradeM.clear();
                cout << "Invalid choice! Try again." << endl;
                cout << "Choose the cards on MARKET want to take in: ";
                cin.getline(tmp, 256);

                token = strtok(tmp, " \t\n\r\f");
                tradeM.push_back(atoi(token));
                token = strtok(NULL, " \t\n\r\f");
                while (token){
                    tradeM.push_back(atoi(token));
                    token = strtok(NULL, " \t\n\r\f");
                }

                cout << "Choose the cards on HANDS want to trade: ";
                cin.getline(tmp, 256);

                token = strtok(tmp, " \t\n\r\f");
                // if nothing input, will trade camels
                if (token != NULL){
                    tradeH.push_back(atoi(token));
                    token = strtok(NULL, " \t\n\r\f");
                    while (token){
                        tradeH.push_back(atoi(token));
                        token = strtok(NULL, " \t\n\r\f");
                    }
                }
            }

            p.Trade(tradeM, tradeH, market);
             
            break;
        }

        //sell
        case 3:
        {
            cout << "Choose the cards on HANDs to sell: ";
            cin.getline(tmp, 256);
            cin.getline(tmp, 256);

            token = strtok(tmp, " \t\n\r\f");
            sellH.push_back(atoi(token));
            token = strtok(NULL, " \t\n\r\f");
            while (token){
                sellH.push_back(atoi(token));
                token = strtok(NULL, " \t\n\r\f");
            }
            
            while (!sellVerify(sellH, p)){
                sellH.clear();
                cout << "Invalid choice! Try again." << endl;
                cout << "Choose the cards on HANDs to sell: ";
                cin.getline(tmp, 256);

                token = strtok(tmp, " \t\n\r\f");
                sellH.push_back(atoi(token));
                token = strtok(NULL, " \t\n\r\f");
                while (token){
                    sellH.push_back(atoi(token));
                    token = strtok(NULL, " \t\n\r\f");
                }
            }

            p.Sell(sellH, tokens, bonus);
            break;
        }

        //take camels
        case 4:
        {
            p.TakeCamel(market, deck); 
            break;
        }
    }
}

bool Game::actionVerify(int act, Player &p){
    bool allCamel = true;
    int nonCML = 0;
    for (int i = 0; i < 5; ++i){
        if (market.getGoods(i+1).getCard() != "CAMEL"){
            allCamel = false;
            nonCML++;
        }
    }

    int gc, dc, sc, rc;
    gc = dc = sc = rc = 0;

    for (int i = 0; i < p.getSize(0); ++i){
        string tmp = p.getHand(0,i).getCard();
        if (tmp == "DIAMD")
            dc++;
        else if (tmp == "GOLD")
            gc++;
        else if (tmp == "SILVR")
            sc++;
        else
            rc++;
    }

    switch (act){
        //take
        case 1:
        {
            if (allCamel || p.getSize(0) == 7)
                return false;
            else 
                return true;
        }

        // trade
        case 2:
        {
            if (nonCML < 2 || (p.getSize(0) + p.getSize(1) < 2))
                return false;
            else
                return true;
        }

        //sell
        case 3:
        {
            if (gc > 2 || dc > 2 || sc > 2 || rc > 1)
                return true;
            else 
                return false;
        }

        //take camel
        case 4:
        {
            if (nonCML < 5) 
                return true;
            else
                return false;
        }
    }

    return false;
}

bool Game::takeVerify(Market &m, int &take){
    if (take < 1 || take > 5 || m.getGoods(take).getCard()=="CAMEL")
        return false;
    else 
        return true;
}

bool Game::tradeVerify(vector<int> &mtake, vector<int> &htake, Player &p, Market &m){
    int msize = mtake.size();
    int hsize = htake.size();
    cout << hsize << endl;

    // Rules: mcards >= hcards; --- total card # conserved 
    // size[0] + mcards - hcards <= 7; --- new size of hand cards should be <= 7
    // mcards - hcards <= size[1]; --- # of camel to exchange <= available camels
    // cannot take camel cards on market

    if (msize < hsize || p.getSize(0) + msize - hsize > 7 || p.getSize(1) < msize - hsize)
        return false;
    else {
         for (int i = 0; i < msize; ++i)
             if (m.getGoods(mtake.at(i)).getCard() == "CAMEL" || mtake.at(i) > 5 || mtake.at(i) < 1)
                 return false;
         for (int i = 0; i < hsize; ++i)
             if (htake.at(i) > 7 || htake.at(i) < 1)
                 return false;
    }        

    return true;
}

bool Game::sellVerify(vector<int> &hsell, Player &p){
    //check if input are within 1 to handsize
    int sellSize = hsell.size();

    for (int i = 0; i < sellSize; ++i)
        if (hsell.at(i) > p.getSize(0) || hsell.at(i) < 1)
            return false;

    // check if only one good
    for (int i = 1; i < sellSize; ++i)
        if (p.getHand(0,hsell.at(i-1)-1).getCard() != p.getHand(0,hsell.at(i)-1).getCard())
            return false;
    // check if goods are DIAMOD, GOLD or SILVR?
    for (int i = 0; i < sellSize; ++i){
        string tmp = p.getHand(0,hsell.at(i)-1).getCard(); 
        if ((tmp == "DIAMD" || tmp == "GOLD" || tmp == "SILVR") && sellSize < 2)
            return false;
    }

    return true;
}

bool Game::RoundTermination(){
    // check the size of deck
    if (getDeck().getsize() == 0)
        return true;
    // check the number of tokens
    int numZero = 0;
    for (int i = 0; i < 6; ++i){
        if (getATokens().getSize(i+1) == 0)
            numZero++;
    }
    if(numZero > 2)
        return true;

    return false;
}

int Game::roundWinner(){
    // camel token
    if (p1.getSize(1) > p2.getSize(1)){
        p1.addPoint(0,5);
        p1.addPoint(2,5);
    }
    else{
        p2.addPoint(0,5);
        p2.addPoint(2,5);
    
    }

    // check the total rupees
    if (p1.getPoints(2) > p2.getPoints(2)){
        p1.addPoint(3,1);
        return 1;
    }
    else if (p1.getPoints(2) < p2.getPoints(2)){
        p2.addPoint(3,1);
        return 2;
    }
    else{
        if (p1.getBToken() > p2.getBToken()){
            p1.addPoint(3,1);
            return 1;
        }
        else if (p1.getBToken() < p2.getBToken()){
            p2.addPoint(3,1);
            return 2;
        }
        else{
            if (p1.getGToken() > p2.getGToken()){
                p1.addPoint(3,1);
                return 1;
            }
            else{
                p2.addPoint(3,1);
                return 2;
            }
        }
    }
}

void Game::display(Player &p){
    system("clear");
    tokens.printTokens();
    bonus.pBonus();
    market.printMarket();
    p.printPlayer();
    cout << "=====================================================================================Round " << getRound() << " Turn " << getTurn() << "=========================================================================================" << endl;
}


#endif
