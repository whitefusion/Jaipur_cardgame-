by Eddie Heredia, Jason Albalah, Xin Bai and Qing-Jie Li
Emails: itizhumid@hotmail.com, jalbala1@jhu.edu, xbai9@jhu.edu, qjli@jhu.edu
Blackboard login ids: eheredi1, jalbala1, xbai9, qli39
Team number: 46


1. We have completed Human-Human play mode. We can play with more than one round. 

2. However, due to some issues associated with 'smarter AI' palyer, we have not incoporate that part currently. But it is hopefully can be implemented well on the demonstration day. 

3. We also attach a separate zip file for AI testing, demonstrating our progress on this aspect. It is just for your consideration, not merged with our main function yet. It will make smart choice depends on the current simuations of market, hand, herds and so on. 

